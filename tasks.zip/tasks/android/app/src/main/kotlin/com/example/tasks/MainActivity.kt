package com.example.tasks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
